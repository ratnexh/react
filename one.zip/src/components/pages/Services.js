import React from 'react'

export default function Services() {
  return (
    <div className="container">
      <h2>Services</h2>
    </div>
  )
}
