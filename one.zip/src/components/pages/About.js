import React from 'react'

export default function About() {
  return (
    <div className="container">
      <h2>About</h2>
    </div>
  )
}
