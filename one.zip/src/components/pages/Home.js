import React from 'react'

export default function Home() {
  return (
    <div className="container">
      <h2>Home</h2>
    </div>
  )
}
