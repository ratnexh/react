import './Home.css'
import React from 'react'
import { Link } from 'react-router-dom'
export default function Home() {
  return (
    <div className="banner">
      <div className="container">
        <div className="banner-text">
          <h1>Home</h1>
          <Link to="/read-more" className="one_btn">
            Read More
          </Link>
        </div>
      </div>
    </div>
  )
}
