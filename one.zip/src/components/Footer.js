import React from 'react'

export default function Footer() {
  return (
    <footer id="footer_one">
      <div className="container">
        <p>Footer</p>
      </div>
    </footer>
  )
}
