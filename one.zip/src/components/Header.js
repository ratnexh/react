import './Header.css'
import { Link } from 'react-router-dom'
import { useState } from 'react'

export default function Header() {
  const [active, setActive] = useState('')

  const handleClick = (event) => {
    setActive(event.target.id)
  }
  return (
    <header id="header_one">
      <div className="container">
        <div className="row">
          <div className="col-sm-2">
            <Link to="/" className="logo">
              ONE<span className='text-light'>.</span>
            </Link>
          </div>
          <div className="col-sm-10">
            <div className="menu">
              <ul>
                <li>
                  <Link
                    className={active === '1' ? 'active' : undefined}
                    id={'1'}
                    onClick={handleClick}
                    to="/"
                  >
                    Home
                  </Link>
                </li>
                <li>
                  <Link
                    className={active === '2' ? 'active' : undefined}
                    id={'2'}
                    onClick={handleClick}
                    to="/about"
                  >
                    About
                  </Link>
                </li>
                <li>
                  <Link
                    className={active === '3' ? 'active' : undefined}
                    id={'3'}
                    onClick={handleClick}
                    to="/services"
                  >
                    Services
                  </Link>
                </li>
                <li>
                  <Link
                    className={active === '4' ? 'active' : undefined}
                    id={'4'}
                    onClick={handleClick}
                    to="/contact"
                  >
                    Contact
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}
