import React from 'react'

export default function Contact() {
  return (
    <div className="container">
      <h2>Contact</h2>
    </div>
  )
}
