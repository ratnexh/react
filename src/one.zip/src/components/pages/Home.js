import './Home.css'
import React from 'react'
import { Link } from 'react-router-dom'
export default function Home() {
  return (
    <div className='home-content'>
      <div className="banner">
        <div className="container">
          <div className="banner-text">
            <h1>Lorem ipsum dolor sit amet consectetur.</h1>
            <Link to="/" className="one_btn mt-4">
              Read More
            </Link>
          </div>
        </div>
      </div>
      <div className="abt-wrapper">
        <div className="container">
          <div className="about_status">
            <div className="row">
              <div className="col-sm-7 abt-lft">
                <h6>Lorem</h6>
                <h2>Ipsum dolor.</h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae omnis odit explicabo ab quam labore molestiae qui voluptatum excepturi dolor, dolore, ex cupiditate deserunt nemo architecto totam, unde eveniet sit?</p>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Corporis est quam quasi mollitia vero ab.</p>
              </div>
              <div className="col-sm-5 abt-ryt">
                <h4>Lorem ipsum dolor sit amet consectetur</h4>
                <h4 className='my-4'>Lorem ipsum dolor sit amet consectetur adipisicing.</h4>
                <h4>Corporis est quam quasi mollitia</h4>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="story-wrapper">
        <div className="container">
          <div className="story">
            <div className="row">
              <div className="col-sm-6"><img src="../../../images/g1.jpg" alt="story"></img></div>
              <div className="col-sm-6 ps-5">
                <h6>Our Story</h6>
                <h2>Lorem ipsum dolor sit amet consectetur adipisicing.</h2>
                <p className='mt-4'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet porro eius voluptatem voluptas tempora vero magnam nesciunt at molestias numquam obcaecati enim natus minima corrupti, excepturi, perspiciatis quis consequuntur. Explicabo blanditiis amet excepturi neque aperiam consectetur labore pariatur, tenetur ducimus!</p>
                <Link to="/" className="one_btn mt-4">Read More</Link>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="wyUs-wrapper">
        <div className="container">
          <div className="whyUs">
            <div className="row">
              <div className="col-sm-6">
                <h6>Lorem dolor</h6>
                <h2>Lorem ipsum us</h2>
                <p className='mt-4 pe-5'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet porro eius voluptatem voluptas tempora vero magnam nesciunt at molestias numquam obcaecati enim natus minima corrupti, excepturi, perspiciatis quis consequuntur. Explicabo blanditiis amet excepturi neque aperiam consectetur labore pariatur, tenetur ducimus!</p>
                <Link to="/" className="one_btn mt-4">Read More</Link>
              </div>
              <div className="col-sm-6">
                <div className="our-progress">
                  <h5 class="progress-tittle">Quality Services <span class="">60%</span></h5>
                  <div className="progress">
                    <div className="progress-bar" style={{ width: '60%' }}></div>
                  </div>
                </div>
                <div className="our-progress my-4">
                  <h5 class="progress-tittle">Quality Services <span class="">90%</span></h5>
                  <div className="progress">
                    <div className="progress-bar" style={{ width: '90%' }}></div>
                  </div>
                </div>
                <div className="our-progress">
                  <h5 class="progress-tittle">Quality Services <span class="">75%</span></h5>
                  <div className="progress">
                    <div className="progress-bar" style={{ width: '75%' }}></div>
                  </div>
                </div>
                <div className="our-progress my-4">
                  <h5 class="progress-tittle">Quality Services <span class="">95%</span></h5>
                  <div className="progress">
                    <div className="progress-bar" style={{ width: '95%' }}></div>
                  </div>
                </div>
                <div className="our-progress">
                  <h5 class="progress-tittle">Quality Services <span class="">85%</span></h5>
                  <div className="progress">
                    <div className="progress-bar" style={{ width: '85%' }}></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  )
}
